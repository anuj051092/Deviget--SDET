package features.Get_Mars_Photos;

import helpers.API_Requests;


public class Query_By_Martian_Sol {

	/*
	 * this is to get data based on @params for Mars Photos - An overloaded function
	 */
	public static String Get_Mars_Photos(String roverName,String sol) throws Exception
	{
		String api_Endpoint= "https://api.nasa.gov/mars-photos/api/v1/rovers/"+roverName+"/photos?sol="+sol+"&api_key=DEMO_KEY";
	
		  String response = API_Requests.Get_Request(api_Endpoint);
		  
		  return response;
	}
	/*
	 * this is to get data based on @params for Mars Photos - An overloaded function
	 */
	public static String Get_Mars_Photos(String roverName, String sol,String camera) throws Exception
	{
		String api_Endpoint= "https://api.nasa.gov/mars-photos/api/v1/rovers/"+roverName+"/photos?sol="+sol+"&camera="+camera+"&api_key=DEMO_KEY";
	
		  String response = API_Requests.Get_Request(api_Endpoint);
		  
		  return response;
	}
	/*
	 * this is to get data based on Earth Date and Rover Name for Mars Photos
	 */
	public static String Get_Mars_Photos_By_EarthDate(String roverName, String earthDate_yyyy_M_D) throws Exception
	{
		String api_Endpoint= "https://api.nasa.gov/mars-photos/api/v1/rovers/"+roverName+"/photos?earth_date="+earthDate_yyyy_M_D+"&api_key=DEMO_KEY";
	
		  String response = API_Requests.Get_Request(api_Endpoint);
		  
		  return response;
	}
}
