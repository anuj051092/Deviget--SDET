package apiModels;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Rover{
    @JsonProperty("id") 
    public int getId() { 
		 return this.id; } 
    public void setId(int id) { 
		 this.id = id; } 
    int id;
    @JsonProperty("name") 
    public String getName() { 
		 return this.name; } 
    public void setName(String name) { 
		 this.name = name; } 
    String name;
    @JsonProperty("landing_date") 
    public String getLanding_date() { 
		 return this.landing_date; } 
    public void setLanding_date(String landing_date) { 
		 this.landing_date = landing_date; } 
    String landing_date;
    @JsonProperty("launch_date") 
    public String getLaunch_date() { 
		 return this.launch_date; } 
    public void setLaunch_date(String launch_date) { 
		 this.launch_date = launch_date; } 
    String launch_date;
    @JsonProperty("status") 
    public String getStatus() { 
		 return this.status; } 
    public void setStatus(String status) { 
		 this.status = status; } 
    String status;
}