package apiModels;

import com.fasterxml.jackson.annotation.JsonProperty;

	public class Photo{
	    @JsonProperty("id") 
	    public int getId() { 
			 return this.id; } 
	    public void setId(int id) { 
			 this.id = id; } 
	    int id;
	    @JsonProperty("sol") 
	    public int getSol() { 
			 return this.sol; } 
	    public void setSol(int sol) { 
			 this.sol = sol; } 
	    int sol;
	    @JsonProperty("camera") 
	    public Camera getCamera() { 
			 return this.camera; } 
	    public void setCamera(Camera camera) { 
			 this.camera = camera; } 
	    Camera camera;
	    @JsonProperty("img_src") 
	    public String getImg_src() { 
			 return this.img_src; } 
	    public void setImg_src(String img_src) { 
			 this.img_src = img_src; } 
	    String img_src;
	    @JsonProperty("earth_date") 
	    public String getEarth_date() { 
			 return this.earth_date; } 
	    public void setEarth_date(String earth_date) { 
			 this.earth_date = earth_date; } 
	    String earth_date;
	    @JsonProperty("rover") 
	    public Rover getRover() { 
			 return this.rover; } 
	    public void setRover(Rover rover) { 
			 this.rover = rover; } 
	    Rover rover;
	
}
