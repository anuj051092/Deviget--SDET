package apiModels;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
public class All_Photos_SCM {
	 @JsonProperty("photos") 
	    public List<Photo> photos() { 
			 return this.photos; } 
	   
	 public  List<Photo> photos;
}
 

 

