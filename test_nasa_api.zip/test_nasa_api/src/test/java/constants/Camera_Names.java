package constants;

public class Camera_Names {

	public final static String  FHAZ = "FHAZ";
	public final static String  RHAZ = "RHAZ";
	public final static String  MAST = "MAST";
	public final static String  CHEMCAM = "CHEMCAM";
	public final static String  MAHLI= "MAHLI";
	public final static String  MARDI= "MARDI";
	public final static String  NAVCAM= "NAVCAM";
	public final static String  PANCAM = "PANCAM";
	public final static String  MINITES = "MINITES";

}
