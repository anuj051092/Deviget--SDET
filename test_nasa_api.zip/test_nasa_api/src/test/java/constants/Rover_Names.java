package constants;

public class Rover_Names {
	public final static String  curiosity = "Curiosity";
	public final static String  Opportunity = "Opportunity";
	public final static String  Spirit = "Spirit";
}
