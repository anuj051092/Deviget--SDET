package helpers;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class API_Requests {

	
	
	public static String Get_Request(String apiEndpoint ) throws Exception 
	{
		 HttpGet request = new HttpGet(apiEndpoint);
		  CloseableHttpClient httpClient = HttpClients.createDefault();

	     
	      HttpResponse response = httpClient.execute(request);
	      
	      String responseBody = EntityUtils
	              .toString(response.getEntity());
	      return responseBody;
	}
}
