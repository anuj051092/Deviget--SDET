package tests;

import java.lang.reflect.Field;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import apiModels.All_Photos_SCM;
import constants.Camera_Names;
import features.Get_Mars_Photos.Query_By_Martian_Sol;
import constants.Rover_Names;


public class Curiosity_Tests 
{
  @Test
  public void Validate_Photo_Count_Curiosity_And_Others() throws Exception 
  {
	  StringBuilder errors = new StringBuilder();
	// Call function to get all photos of 1000 Sol
	  String martian_1000_Sol_For_Curiosity_Response =   Query_By_Martian_Sol.Get_Mars_Photos( Rover_Names.curiosity, "1000");
	// Convert Json to Class Object using ObjectMapper
	  ObjectMapper mapper = new ObjectMapper();
	All_Photos_SCM martian_1000_Sol_CM = mapper.readValue(martian_1000_Sol_For_Curiosity_Response, All_Photos_SCM.class);
	
	// Get Earth Date equal of 1000 SOl
	String earthDate = martian_1000_Sol_CM.photos().get(0).getEarth_date();
	
	// Get Mars Photos by Earth Date
	String martian_1000_Sol_ByEarth_Date_Response =   Query_By_Martian_Sol.Get_Mars_Photos_By_EarthDate(Rover_Names.curiosity,earthDate);
	// Convert Json to Class Object using ObjectMapper
	mapper = new ObjectMapper();
	All_Photos_SCM martian_1000_Sol_By_EarthDate_CM = mapper.readValue(martian_1000_Sol_ByEarth_Date_Response, All_Photos_SCM.class);
	
	// Compare First 10 photos by 1000 Sol and Earth Date
	for(int i=0;i<10;i++)
	{
		if(!martian_1000_Sol_CM.photos().get(i).getImg_src().equalsIgnoreCase(martian_1000_Sol_By_EarthDate_CM.photos().get(i).getImg_src()))
			errors.append("Photos Mismatch for Curosity at 1000 Sol and Earth Date: "+ earthDate +" for position: "+ (i+1));
	}
	
	// Get All Camera fields and loop though them
	Camera_Names myStuff = new Camera_Names();
	Field[] fields = myStuff.getClass().getDeclaredFields();
	 for(int cameraCount=0;cameraCount<fields.length;cameraCount++)
	 { 
		 // Get Mars photos by rover Curiosity and camera
		String curiosity_Response =   Query_By_Martian_Sol.Get_Mars_Photos( Rover_Names.curiosity, "1000",fields[cameraCount].getName());
		 mapper = new ObjectMapper();
		All_Photos_SCM curiosity_CM = mapper.readValue(curiosity_Response, All_Photos_SCM.class);

		// Get Mars photos by rover Opportunity and camera
		 String opportunity_Response =   Query_By_Martian_Sol.Get_Mars_Photos( Rover_Names.Opportunity, "1000",fields[cameraCount].getName());
		 mapper = new ObjectMapper();
		All_Photos_SCM opportunity_CM = mapper.readValue(opportunity_Response, All_Photos_SCM.class);

		// Get Mars photos by rover Spirit and camera
		
		 String spirit_Response =   Query_By_Martian_Sol.Get_Mars_Photos( Rover_Names.Spirit, "1000",fields[cameraCount].getName());
		 mapper = new ObjectMapper();
		All_Photos_SCM spirit_CM = mapper.readValue(spirit_Response, All_Photos_SCM.class);
int pictureSize_Of_Curisoity_For_Current_Camera = curiosity_CM.photos().size();
int pictureSize_Of_Opportunity_For_Current_Camera = opportunity_CM.photos().size();
int pictureSize_Of_Spirit_For_Current_Camera = spirit_CM.photos().size();
if(pictureSize_Of_Opportunity_For_Current_Camera!=0)
		if(pictureSize_Of_Curisoity_For_Current_Camera>(10*pictureSize_Of_Opportunity_For_Current_Camera))
			errors.append("Curiosity took more pictures than expected. <CameraName: >"+fields[cameraCount].toString()+ "<Curiosity Picture Count:> "+ pictureSize_Of_Curisoity_For_Current_Camera + "<Opportunity Picture Count:> "+ pictureSize_Of_Opportunity_For_Current_Camera);
if(pictureSize_Of_Opportunity_For_Current_Camera!=0)		
if(pictureSize_Of_Curisoity_For_Current_Camera>(10*pictureSize_Of_Spirit_For_Current_Camera))
			errors.append("Curiosity took more pictures than expected. <CameraName: >"+fields[cameraCount].toString()+ "<Curiosity Picture Count:> "+ pictureSize_Of_Curisoity_For_Current_Camera + "<Opportunity Picture Count:> "+ pictureSize_Of_Spirit_For_Current_Camera);
		
	 }
	 if(!errors.toString().equals(""))
		 System.out.print(errors);
  }
  
}
